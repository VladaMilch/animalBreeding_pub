## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE-----------------------------------------------------
library(devtools)
install_github("IMSBComputationalBiology/animalBreedingProj", 
               subdir="animalBreeding",
               auth_token = "f6024685998b779a9db258994a7b4e44468b754c")
library(animalBreeding)

## -----------------------------------------------------------------------------

#calculate_needed_litters()

