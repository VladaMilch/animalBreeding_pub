library(testthat)
library(animalBreeding)

test_check("animalBreeding")
